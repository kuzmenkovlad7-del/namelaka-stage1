This bundle contains the WORKING mirror used for localhost:3000.
mirror/namelaka.ua -> ua/en + assets/media + compiled JS/CSS.
Log: /Users/a1111/Downloads/pack_namelaka_working.log
Found mirror: /Users/a1111/projects/namelaka-clone/mirror/namelaka.ua
