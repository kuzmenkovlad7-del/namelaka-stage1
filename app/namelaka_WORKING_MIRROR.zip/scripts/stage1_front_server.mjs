import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const PORT = Number(process.env.PORT || 3000);
const ROOT = path.resolve(process.env.ROOT || ".");
const API_ORIGIN = process.env.API_ORIGIN || "https://namelaka.ua";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".eot": "application/vnd.ms-fontobject",
  ".map": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
};

function extOf(p) {
  return path.extname(p.split("?")[0]).toLowerCase();
}
function mimeOf(p) {
  return MIME[extOf(p)] || "application/octet-stream";
}
function isFile(abs) {
  try { return fs.statSync(abs).isFile(); } catch { return false; }
}
function safeAbs(urlPath) {
  const decoded = decodeURIComponent(urlPath || "/").replace(/\0/g, "");
  const norm = path.posix.normalize("/" + decoded.replace(/^\/+/, ""));
  const abs = path.resolve(ROOT, "." + norm);
  if (!abs.startsWith(ROOT)) return null;
  return abs;
}
function send(res, code, headers, body) {
  res.writeHead(code, headers);
  res.end(body);
}
function sendFile(res, abs, extraHeaders = {}) {
  const buf = fs.readFileSync(abs);
  send(res, 200, {
    "Content-Type": mimeOf(abs),
    "Content-Length": String(buf.length),
    ...extraHeaders,
  }, buf);
}
function uniq(arr) {
  const out = [];
  const seen = new Set();
  for (const v of arr) {
    if (!v || seen.has(v)) continue;
    seen.add(v);
    out.push(v);
  }
  return out;
}
function isAssetPath(p) {
  if (p.startsWith("/api/")) return false;
  if (/\.(js|mjs|css|map|json|svg|png|jpe?g|webp|gif|ico|woff2?|ttf|otf|eot|txt|mp4|webm)$/i.test(p)) return true;
  if (/(^|\/)(assets|media|fonts|lottie)\//i.test(p)) return true;
  if (/\/(chunk|main|polyfills|styles|runtime|index)-[^/]+\.(js|css|map)$/i.test(p)) return true;
  return false;
}

// главное: лечим deep-links типа /ua/catalog/main-*.js -> /ua/main-*.js и /main-*.js
function assetCandidates(pathname) {
  const p = pathname.replace(/\/+/g, "/");
  const out = [p];

  // 1) если запрос внутри /ua/catalog/... или /ua/product/... — режем префикс страницы
  out.push(p.replace(/^\/(ua|en)\/(catalog|product|cart|checkout)\//i, "/$1/"));

  // 2) если это /ua/catalog/media/... -> /ua/media/...
  out.push(p.replace(/^\/(ua|en)\/(catalog|product|cart|checkout)\/media\//i, "/$1/media/"));
  out.push(p.replace(/^\/(ua|en)\/(catalog|product|cart|checkout)\/assets\//i, "/$1/assets/"));

  // 3) без локали
  out.push(p.replace(/^\/(ua|en)\//i, "/"));

  // 4) чанки/бандлы: пробуем по basename
  const base = path.posix.basename(p);
  if (/\.(js|css|map)$/i.test(base) && /(chunk|main|polyfills|styles|runtime|index)-/i.test(base)) {
    out.push(`/ua/${base}`, `/en/${base}`, `/${base}`);
  }

  // 5) кросс-локаль
  if (p.startsWith("/ua/")) out.push(p.replace(/^\/ua\//, "/en/"));
  if (p.startsWith("/en/")) out.push(p.replace(/^\/en\//, "/ua/"));

  return uniq(out);
}

function injectBase(html, locale) {
  const baseTag = `<base href="/${locale}/">`;
  if (/<base\s+href=/i.test(html)) {
    return html.replace(/<base\s+href=["'][^"']*["']\s*\/?>/i, baseTag);
  }
  return html.replace(/<head([^>]*)>/i, `<head$1>\n  ${baseTag}`);
}

async function fetchAndCache(candidateUrlPath, wantExt) {
  const u = `${API_ORIGIN}${candidateUrlPath}`;
  const r = await fetch(u, { redirect: "follow", headers: { "user-agent": "stage1/1.0", "accept": "*/*" } });
  if (!r.ok) return null;

  const ct = (r.headers.get("content-type") || "").toLowerCase();

  // критично: никогда не сохраняем HTML как js/css/ttf
  if (wantExt && wantExt !== ".html") {
    if (ct.includes("text/html")) return null;
  }

  const buf = Buffer.from(await r.arrayBuffer());
  if (!buf.length) return null;

  const abs = safeAbs(candidateUrlPath);
  if (!abs) return null;

  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, buf);
  return { buf, contentType: ct || mimeOf(candidateUrlPath) };
}

const server = http.createServer(async (req, res) => {
  try {
    const host = req.headers.host || `localhost:${PORT}`;
    const url = new URL(req.url || "/", `http://${host}`);
    const pathname = url.pathname.replace(/\/+/g, "/");

    if (pathname === "/") {
      res.writeHead(302, { Location: "/ua/" }); res.end(); return;
    }
    if (pathname === "/ua" || pathname === "/en") {
      res.writeHead(302, { Location: pathname + "/" }); res.end(); return;
    }

    // API proxy (для stage1)
    if (pathname.startsWith("/api/")) {
      const target = `${API_ORIGIN}${pathname}${url.search || ""}`;
      const method = (req.method || "GET").toUpperCase();
      const body = ["GET", "HEAD"].includes(method) ? undefined : Buffer.from(await (async () => {
        const chunks = [];
        for await (const c of req) chunks.push(c);
        return Buffer.concat(chunks);
      })());

      const upstream = await fetch(target, {
        method,
        headers: Object.fromEntries(Object.entries(req.headers).filter(([k]) => !["host","content-length","accept-encoding","connection"].includes(k.toLowerCase()))),
        body
      });

      const arr = Buffer.from(await upstream.arrayBuffer());
      res.statusCode = upstream.status;
      upstream.headers.forEach((v, k) => {
        if (["content-encoding","transfer-encoding","content-length","connection"].includes(k.toLowerCase())) return;
        res.setHeader(k, v);
      });
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Content-Length", String(arr.length));
      res.end(arr);
      return;
    }

    // assets
    if (isAssetPath(pathname)) {
      const wantExt = extOf(pathname);
      const cands = assetCandidates(pathname);

      for (const p of cands) {
        const abs = safeAbs(p);
        if (abs && isFile(abs)) {
          sendFile(res, abs, { "Cache-Control": "public, max-age=86400" });
          return;
        }
      }

      // если файла нет в зеркале — пробуем подтянуть с API_ORIGIN и закешировать
      for (const p of cands) {
        const got = await fetchAndCache(p, wantExt);
        if (got) {
          send(res, 200, {
            "Content-Type": got.contentType,
            "Cache-Control": "public, max-age=86400",
            "Content-Length": String(got.buf.length),
          }, got.buf);
          return;
        }
      }

      send(res, 404, { "Content-Type": "text/plain; charset=utf-8" }, "Not Found");
      return;
    }

    // html routes -> всегда отдаём index.html с <base>
    const locale = pathname.startsWith("/en") ? "en" : "ua";
    const indexPath = `/${locale}/index.html`;
    const abs = safeAbs(indexPath);

    if (!abs || !isFile(abs)) {
      send(res, 404, { "Content-Type": "text/plain; charset=utf-8" }, "Missing index.html in mirror");
      return;
    }

    let html = fs.readFileSync(abs, "utf8");
    html = injectBase(html, locale);

    send(res, 200, {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
    }, html);
  } catch (e) {
    send(res, 500, { "Content-Type": "text/plain; charset=utf-8" }, String(e?.message || e));
  }
});

server.listen(PORT, () => {
  console.log("Stage1 server ready http://localhost:" + PORT);
  console.log("ROOT=" + ROOT);
  console.log("API_ORIGIN=" + API_ORIGIN);
});
