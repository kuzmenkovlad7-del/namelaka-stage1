#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-$HOME/projects/namelaka-clone/mirror/namelaka.ua}"
LOG_DIR="${LOG_DIR:-$HOME/projects/logs}"
FRONT_SERVER="${FRONT_SERVER:-$HOME/projects/stage1_front_server.mjs}"
FRONT_LOG="${FRONT_LOG:-$LOG_DIR/namelaka-front.log}"
BACK_LOG="${BACK_LOG:-$LOG_DIR/namelaka-back.log}"
API_ORIGIN="${API_ORIGIN:-https://namelaka.ua}"
FRONT_PORT="${FRONT_PORT:-3000}"
BACK_PORT="${BACK_PORT:-9000}"

mkdir -p "$LOG_DIR"

echo "[1/6] stop old front"
lsof -ti tcp:${FRONT_PORT} | xargs kill -9 2>/dev/null || true
pkill -f "stage1_front_server.mjs" 2>/dev/null || true

echo "[2/6] write front server hard-fix"
cat <<'NODE' > "$FRONT_SERVER"
import http from 'http'
import fs from 'fs'
import path from 'path'

const ROOT = path.resolve(process.env.ROOT || '/Users/a1111/projects/namelaka-clone/mirror/namelaka.ua')
const API_ORIGIN = process.env.API_ORIGIN || 'https://namelaka.ua'
const PORT = Number(process.env.PORT || 3000)

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.eot': 'application/vnd.ms-fontobject',
  '.map': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8'
}

function extOf(p) { return path.extname(p).toLowerCase() }
function mimeOf(p) { return MIME[extOf(p)] || 'application/octet-stream' }

function existsFile(abs) {
  try { return fs.statSync(abs).isFile() } catch { return false }
}

function toAbs(urlPath) {
  const normalized = path.posix.normalize('/' + decodeURIComponent(urlPath).replace(/\\/g, '/'))
  const rel = normalized.replace(/^\/+/, '')
  const abs = path.join(ROOT, rel)
  if (!path.resolve(abs).startsWith(ROOT)) return null
  return abs
}

function send(res, code, headers, body) {
  res.writeHead(code, headers)
  res.end(body)
}

function sendFile(res, abs, code = 200, extraHeaders = {}) {
  const buf = fs.readFileSync(abs)
  send(res, code, {
    'Content-Type': mimeOf(abs),
    'Content-Length': String(buf.length),
    ...extraHeaders
  }, buf)
}

function unique(arr) {
  const out = []
  const seen = new Set()
  for (const v of arr) {
    if (!v || seen.has(v)) continue
    seen.add(v)
    out.push(v)
  }
  return out
}

function normalizePathname(pathname) {
  return pathname.startsWith('/') ? pathname : '/' + pathname
}

function isAssetRequest(pathname) {
  if (pathname.startsWith('/api/')) return false
  if (/\.(js|mjs|css|map|json|svg|png|jpe?g|webp|gif|ico|woff2?|ttf|otf|eot|txt)$/i.test(pathname)) return true
  if (/(^|\/)(assets|media|fonts|lottie)\//.test(pathname)) return true
  if (/\/(chunk|main|polyfills|styles|runtime|index)-[^/]+\.(js|css|map)$/i.test(pathname)) return true
  return false
}

function buildAssetCandidates(pathname) {
  pathname = normalizePathname(pathname)
  const out = [pathname]

  const localeMatch = pathname.match(/^\/(ua|en)(\/.*)?$/)
  if (localeMatch) {
    const locale = localeMatch[1]
    const other = locale === 'ua' ? 'en' : 'ua'
    const rest = localeMatch[2] || '/'

    out.push(`/${other}${rest}`)

    if (rest.startsWith('/product/')) {
      const noProduct = rest.replace('/product/', '/')
      out.push(`/${locale}${noProduct}`)
      out.push(`/${other}${noProduct}`)

      if (/^\/(chunk|main|polyfills|styles|runtime|index)-[^/]+\.(js|css|map)$/i.test(noProduct)) {
        const basename = noProduct.replace(/^\//, '')
        out.push(`/${basename}`)
      }
    }

    if (/^\/(chunk|main|polyfills|styles|runtime|index)-[^/]+\.(js|css|map)$/i.test(rest)) {
      const basename = rest.replace(/^\//, '')
      out.push(`/${basename}`)
      out.push(`/${other}/${basename}`)
    }
  }

  if (pathname.startsWith('/product/')) {
    out.push(`/ua${pathname}`)
    out.push(`/en${pathname}`)
    out.push(pathname.replace('/product/', '/'))
  }

  if (pathname.startsWith('/assets/') || pathname.startsWith('/media/') || pathname.startsWith('/fonts/') || pathname.startsWith('/lottie/')) {
    out.push(`/ua${pathname}`)
    out.push(`/en${pathname}`)
  }

  if (/^\/(chunk|main|polyfills|styles|runtime|index)-[^/]+\.(js|css|map)$/i.test(pathname)) {
    out.push(`/ua${pathname}`)
    out.push(`/en${pathname}`)
  }

  out.push(pathname.replace('/en/product/', '/en/'))
  out.push(pathname.replace('/ua/product/', '/ua/'))
  out.push(pathname.replace('/en/product/', '/ua/'))
  out.push(pathname.replace('/ua/product/', '/en/'))

  return unique(out.map(p => p.replace(/\/+/g, '/')))
}

async function readReqBody(req) {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  return chunks.length ? Buffer.concat(chunks) : undefined
}

function filterReqHeaders(headers) {
  const skip = new Set(['host', 'content-length', 'connection', 'accept-encoding'])
  const out = {}
  for (const [k, v] of Object.entries(headers)) {
    if (!k) continue
    if (skip.has(k.toLowerCase())) continue
    out[k] = v
  }
  return out
}

function filterRespHeaders(headers) {
  const out = {}
  headers.forEach((value, key) => {
    if (key.toLowerCase() === 'content-encoding') return
    if (key.toLowerCase() === 'transfer-encoding') return
    out[key] = value
  })
  return out
}

function injectBaseHref(html, locale) {
  const baseTag = `<base href="/${locale}/">`
  if (/<base\s+href=/i.test(html)) {
    return html.replace(/<base\s+href=["'][^"']*["']\s*\/?\s*>/i, baseTag)
  }
  return html.replace(/<head([^>]*)>/i, `<head$1>\n  ${baseTag}`)
}

async function tryFetchAndCache(candidatePaths, queryString, res) {
  for (const p of candidatePaths) {
    try {
      const url = `${API_ORIGIN}${p}${queryString || ''}`
      const r = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': 'namelaka-stage1-mirror/1.0',
          'Accept': '*/*'
        }
      })
      if (!r.ok) continue

      const contentType = (r.headers.get('content-type') || '').toLowerCase()
      if (/\.(js|css|map|json|ttf|woff2?|svg)$/i.test(p) && contentType.includes('text/html')) continue

      const arr = new Uint8Array(await r.arrayBuffer())
      const abs = toAbs(p)
      if (abs) {
        fs.mkdirSync(path.dirname(abs), { recursive: true })
        fs.writeFileSync(abs, arr)
      }

      send(res, 200, {
        'Content-Type': r.headers.get('content-type') || mimeOf(p),
        'Content-Length': String(arr.length),
        'Cache-Control': 'public, max-age=86400'
      }, Buffer.from(arr))
      return true
    } catch {
      // try next
    }
  }
  return false
}

const server = http.createServer(async (req, res) => {
  try {
    const host = req.headers.host || `localhost:${PORT}`
    const url = new URL(req.url || '/', `http://${host}`)
    const pathname = normalizePathname(url.pathname)
    const query = url.search || ''

    if (pathname === '/') {
      res.writeHead(302, { Location: '/ua/' })
      res.end()
      return
    }
    if (pathname === '/ua' || pathname === '/en') {
      res.writeHead(302, { Location: `${pathname}/` })
      res.end()
      return
    }

    if (pathname.startsWith('/api/')) {
      const target = `${API_ORIGIN}${pathname}${query}`
      const method = (req.method || 'GET').toUpperCase()
      const body = ['GET', 'HEAD'].includes(method) ? undefined : await readReqBody(req)

      const upstream = await fetch(target, {
        method,
        headers: filterReqHeaders(req.headers),
        body
      })

      const arr = new Uint8Array(await upstream.arrayBuffer())
      const headers = filterRespHeaders(upstream.headers)
      headers['Content-Length'] = String(arr.length)
      headers['Access-Control-Allow-Origin'] = '*'
      send(res, upstream.status, headers, Buffer.from(arr))
      return
    }

    if (isAssetRequest(pathname)) {
      const candidates = buildAssetCandidates(pathname)

      for (const p of candidates) {
        const abs = toAbs(p)
        if (abs && existsFile(abs)) {
          sendFile(res, abs, 200, { 'Cache-Control': 'public, max-age=86400' })
          return
        }
      }

      const ok = await tryFetchAndCache(candidates, query, res)
      if (ok) return

      send(res, 404, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Not Found')
      return
    }

    const locale = pathname.startsWith('/en') ? 'en' : 'ua'
    const localePrefix = `/${locale}`
    const tail = pathname.startsWith(localePrefix) ? pathname.slice(localePrefix.length) : pathname

    const docCandidates = []
    if (tail && tail !== '/' && tail.endsWith('.html')) docCandidates.push(`${localePrefix}${tail}`)
    if (tail && tail !== '/') docCandidates.push(`${localePrefix}${tail}/index.html`)
    docCandidates.push(`${localePrefix}/index.html`)

    let htmlAbs = null
    for (const p of unique(docCandidates)) {
      const abs = toAbs(p)
      if (abs && existsFile(abs)) {
        htmlAbs = abs
        break
      }
    }

    if (!htmlAbs) {
      send(res, 404, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Not Found')
      return
    }

    let html = fs.readFileSync(htmlAbs, 'utf8')
    html = injectBaseHref(html, locale)

    send(res, 200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store'
    }, html)
  } catch (err) {
    send(res, 500, { 'Content-Type': 'text/plain; charset=utf-8' }, `Server error: ${err?.message || err}`)
  }
})

server.listen(PORT, () => {
  console.log(`Stage1 front server is ready on http://localhost:${PORT}`)
  console.log(`ROOT=${ROOT}`)
  console.log(`API_ORIGIN=${API_ORIGIN}`)
})
NODE

echo "[3/6] syntax check front server"
node --check "$FRONT_SERVER"

echo "[4/6] ensure backend :${BACK_PORT}"
BACK_CODE="$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:${BACK_PORT}/app" || true)"
if [ "$BACK_CODE" = "000" ]; then
  (
    cd "$HOME/projects/namelaka-admin"
    nohup npx medusa develop --host 0.0.0.0 --port ${BACK_PORT} > "$BACK_LOG" 2>&1 &
  ) || true
  sleep 4
fi

echo "[5/6] start front :${FRONT_PORT}"
ROOT="$ROOT" API_ORIGIN="$API_ORIGIN" PORT="$FRONT_PORT" nohup node "$FRONT_SERVER" > "$FRONT_LOG" 2>&1 &
sleep 2

echo "[6/6] warm + checks"
WARM=(
  "/ua/"
  "/en/"
  "/ua/catalog/"
  "/en/catalog/"
  "/ua/cart/"
  "/en/cart/"
  "/ua/product/01tSp00000B7mBFIAZ?categoryId=a0ESp0000028EvtMAE"
  "/en/product/01tSp00000B7mBFIAZ?categoryId=a0ESp0000028EvtMAE"
  "/api/categories?lang=ua"
  "/api/categories?lang=en"
)
for p in "${WARM[@]}"; do
  curl -L -s -o /dev/null "http://localhost:${FRONT_PORT}${p}" || true
done

CHECK=(
  "/ua/"
  "/en/"
  "/ua/assets/icons/search-primary.svg"
  "/en/assets/icons/search-primary.svg"
  "/ua/assets/icons/logo-header-primary.svg"
  "/en/assets/icons/logo-header-primary.svg"
  "/ua/assets/icons/cart-secondary.svg"
  "/en/assets/icons/cart-secondary.svg"
  "/ua/assets/icons/user-icon-disabled.svg"
  "/en/assets/icons/user-icon-disabled.svg"
  "/ua/assets/icons/double-tick-primary.svg"
  "/en/assets/icons/double-tick-primary.svg"
  "/ua/assets/icons/person-disabled.svg"
  "/en/assets/icons/person-disabled.svg"
  "/ua/assets/icons/patterns/pattern.svg"
  "/en/assets/icons/patterns/pattern.svg"
  "/ua/assets/lottie/fast-loader.json"
  "/en/assets/lottie/fast-loader.json"
  "/ua/media/AvenirNextCyr-Regular-WUUMAWTX.ttf"
  "/en/media/AvenirNextCyr-Regular-WUUMAWTX.ttf"
  "/api/categories?lang=ua"
  "/api/categories?lang=en"
)
for p in "${CHECK[@]}"; do
  code="$(curl -L -s -o /dev/null -w '%{http_code}' "http://localhost:${FRONT_PORT}${p}" || true)"
  printf "%-62s -> %s\n" "${p}" "${code}"
done

echo
echo "DONE"
echo "Front UA: http://localhost:${FRONT_PORT}/ua/"
echo "Front EN: http://localhost:${FRONT_PORT}/en/"
echo "Admin:    http://localhost:${BACK_PORT}/app"
echo "Login:    admin@namelaka.local"
echo "Pass:     StrongPass123!"
echo
echo "Logs:"
echo "tail -f ${FRONT_LOG}"
echo "tail -f ${BACK_LOG}"
