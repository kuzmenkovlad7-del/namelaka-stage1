const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = process.env.ROOT || path.join(process.env.HOME, "projects/namelaka-clone/mirror/namelaka.ua");
const PORT = Number(process.env.PORT || 3000);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".ico": "image/x-icon",
};

function safeJoin(root, reqPath) {
  const clean = decodeURIComponent(reqPath.split("?")[0]).replace(/\0/g, "");
  const joined = path.join(root, clean);
  if (!joined.startsWith(root)) return null;
  return joined;
}

function injectBase(html, baseHref) {
  if (html.includes("<base ")) {
    return html.replace(/<base[^>]*href="[^"]*"[^>]*>/i, `<base href="${baseHref}">`);
  }
  return html.replace(/<head([^>]*)>/i, `<head$1><base href="${baseHref}">`);
}

function send(res, code, body, ctype) {
  res.writeHead(code, { "content-type": ctype, "cache-control": "no-store" });
  res.end(body);
}

const server = http.createServer((req, res) => {
  try {
    const urlPath = (req.url || "/").split("?")[0];

    const filePath = safeJoin(ROOT, urlPath);
    if (!filePath) return send(res, 400, "bad request", "text/plain; charset=utf-8");

    // 1) если запрос к реальному файлу
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const ctype = MIME[ext] || "application/octet-stream";
      const buf = fs.readFileSync(filePath);
      return send(res, 200, buf, ctype);
    }

    // 2) если запрос к папке и там есть index.html
    if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
      const idx = path.join(filePath, "index.html");
      if (fs.existsSync(idx)) {
        const html = fs.readFileSync(idx, "utf8");
        return send(res, 200, html, MIME[".html"]);
      }
    }

    // 3) SPA fallback для /ua/* и /en/* с base
    if (urlPath.startsWith("/ua")) {
      const idx = path.join(ROOT, "ua", "index.html");
      if (fs.existsSync(idx)) {
        let html = fs.readFileSync(idx, "utf8");
        html = injectBase(html, "/ua/");
        return send(res, 200, html, MIME[".html"]);
      }
    }

    if (urlPath.startsWith("/en")) {
      const idx = path.join(ROOT, "en", "index.html");
      if (fs.existsSync(idx)) {
        let html = fs.readFileSync(idx, "utf8");
        html = injectBase(html, "/en/");
        return send(res, 200, html, MIME[".html"]);
      }
    }

    // 4) корень
    if (urlPath === "/" || urlPath === "") {
      return send(res, 302, Buffer.from(""), "text/plain; charset=utf-8");
    }

    return send(res, 404, "not found", "text/plain; charset=utf-8");
  } catch (e) {
    return send(res, 500, String(e && e.message ? e.message : e), "text/plain; charset=utf-8");
  }
});

server.listen(PORT, () => {
  console.log("Mirror server ready");
  console.log("ROOT=" + ROOT);
  console.log("PORT=" + PORT);
});
