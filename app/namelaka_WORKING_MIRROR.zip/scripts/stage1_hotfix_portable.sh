#!/usr/bin/env bash
set -euo pipefail

ROOT="${HOME}/projects/namelaka-clone/mirror/namelaka.ua"
LOG_DIR="${HOME}/projects/logs"
FRONT_JS="${HOME}/projects/stage1_front_server.mjs"
FRONT_LOG="${LOG_DIR}/namelaka-front.log"
BACK_LOG="${LOG_DIR}/namelaka-back.log"

# Пока оставляем remote-origin для каталога как в Вашем этапе
API_ORIGIN="https://namelaka.ua"

mkdir -p "${LOG_DIR}"

echo "[1/7] stop front :3000"
lsof -ti tcp:3000 | xargs kill -9 2>/dev/null || true
pkill -f "stage1_front_server.mjs" 2>/dev/null || true

echo "[2/7] write portable front server (no mapfile)"
cat <<'JS' > "${FRONT_JS}"
import http from "http";
import https from "https";
import fs from "fs";
import path from "path";
import { URL } from "url";

const { createReadStream, existsSync, statSync } = fs;
const fsp = fs.promises;

const ROOT = process.env.ROOT || "";
const API_ORIGIN = process.env.API_ORIGIN || "https://namelaka.ua";
const PORT = Number(process.env.PORT || 3000);
const API_URL = new URL(API_ORIGIN);
const API_CLIENT = API_URL.protocol === "https:" ? https : http;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".map": "application/json; charset=utf-8",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
};

const ASSET_EXT = new Set([
  ".js", ".mjs", ".css", ".json", ".map",
  ".svg", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico",
  ".woff", ".woff2", ".ttf", ".otf",
  ".mp4", ".webm"
]);

function normalize(p) {
  if (!p) return "/";
  let s = p.replace(/\/{2,}/g, "/");
  if (!s.startsWith("/")) s = "/" + s;
  return s;
}

function extOf(p) {
  return path.extname(p.split("?")[0]).toLowerCase();
}

function isAssetPath(p) {
  const x = normalize(p);
  if (x.startsWith("/api/")) return false;
  if (x.includes("/assets/") || x.includes("/media/")) return true;
  if (/\/chunk-[^/]+\.(js|css)$/i.test(x)) return true;
  return ASSET_EXT.has(extOf(x));
}

function safeAbs(urlPath) {
  const rel = normalize(urlPath).replace(/^\/+/, "");
  const abs = path.resolve(ROOT, rel);
  const rootAbs = path.resolve(ROOT);
  if (!abs.startsWith(rootAbs)) {
    throw new Error("Path traversal blocked");
  }
  return abs;
}

function localeCandidates(urlPath) {
  const p = normalize(urlPath);
  const out = [];
  const add = (v) => {
    const n = normalize(v);
    if (!out.includes(n)) out.push(n);
  };

  add(p);

  // locale fallbacks
  if (p.startsWith("/en/")) {
    const rest = p.slice(4);
    add("/ua/" + rest);
    add("/" + rest);
  } else if (p.startsWith("/ua/")) {
    const rest = p.slice(4);
    add("/" + rest);
  }

  // chunks fallbacks
  if (/^\/en\/chunk-[^/]+\.(js|css)$/i.test(p)) {
    const chunk = p.replace(/^\/en\//, "/");
    add(chunk);
    add("/ua" + chunk);
  }
  if (/^\/ua\/chunk-[^/]+\.(js|css)$/i.test(p)) {
    const chunk = p.replace(/^\/ua\//, "/");
    add(chunk);
  }

  return out;
}

function diskCandidates(urlPath) {
  const p = normalize(urlPath);
  const out = [];
  const add = (v) => {
    try {
      const abs = safeAbs(v);
      if (!out.includes(abs)) out.push(abs);
    } catch (_) {}
  };

  for (const c of localeCandidates(p)) add(c);

  // if route-like path, also index.html candidates
  if (!extOf(p)) {
    for (const c of localeCandidates(p)) {
      add(c.endsWith("/") ? c + "index.html" : c + "/index.html");
    }
  }

  return out;
}

async function findExistingFile(urlPath) {
  for (const abs of diskCandidates(urlPath)) {
    if (existsSync(abs)) {
      try {
        if (statSync(abs).isFile()) return abs;
      } catch (_) {}
    }
  }
  return null;
}

async function ensureDir(fileAbs) {
  await fsp.mkdir(path.dirname(fileAbs), { recursive: true });
}

function rewriteCookie(v) {
  return String(v)
    .replace(/;\s*Domain=[^;]+/gi, "; Domain=localhost")
    .replace(/;\s*Secure/gi, "")
    .replace(/;\s*SameSite=None/gi, "; SameSite=Lax");
}

function copyHeadersFromProxy(res, headersObj) {
  const hopByHop = new Set([
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailer", "transfer-encoding", "upgrade"
  ]);

  for (const [k, v] of Object.entries(headersObj)) {
    const lk = String(k).toLowerCase();
    if (hopByHop.has(lk)) continue;
    if (lk === "set-cookie") continue;
    if (lk === "content-encoding") continue;
    if (lk === "content-length") continue;

    if (lk === "location" && typeof v === "string") {
      res.setHeader(k, v.replace(API_ORIGIN, "http://localhost:3000"));
      continue;
    }

    if (typeof v !== "undefined") res.setHeader(k, v);
  }
}

function fetchRemoteBinary(remotePath, reqHeaders = {}) {
  return new Promise((resolve, reject) => {
    const target = new URL(remotePath, API_ORIGIN);
    const mod = target.protocol === "https:" ? https : http;

    const headers = { ...reqHeaders };
    delete headers.host;
    delete headers["content-length"];

    const r = mod.request(
      {
        protocol: target.protocol,
        hostname: target.hostname,
        port: target.port || (target.protocol === "https:" ? 443 : 80),
        method: "GET",
        path: target.pathname + target.search,
        headers,
      },
      (resp) => {
        const chunks = [];
        resp.on("data", (d) => chunks.push(d));
        resp.on("end", () => {
          resolve({
            status: resp.statusCode || 0,
            headers: resp.headers || {},
            body: Buffer.concat(chunks),
          });
        });
      }
    );

    r.on("error", reject);
    r.end();
  });
}

async function sendFile(res, fileAbs) {
  const ext = extOf(fileAbs);
  const ctype = MIME[ext] || "application/octet-stream";

  res.statusCode = 200;
  res.setHeader("content-type", ctype);

  if (ext === ".html") {
    res.setHeader("cache-control", "no-store, no-cache, must-revalidate");
  } else {
    res.setHeader("cache-control", "public, max-age=3600");
  }

  createReadStream(fileAbs).pipe(res);
}

async function cacheAndSendAsset(req, res, urlPath) {
  const reqExt = extOf(urlPath);
  const cands = localeCandidates(urlPath);

  for (const rp of cands) {
    try {
      const remote = await fetchRemoteBinary(rp, req.headers);
      if (remote.status !== 200) continue;

      const remoteCT = String(remote.headers["content-type"] || "").toLowerCase();

      // critical: do not return html for js/css assets
      if ((reqExt === ".js" || reqExt === ".mjs" || reqExt === ".css") && remoteCT.includes("text/html")) {
        continue;
      }

      // save under requested path
      const saveAbsReq = safeAbs(urlPath);
      await ensureDir(saveAbsReq);
      await fsp.writeFile(saveAbsReq, remote.body);

      // optional: also save under source fallback path
      try {
        const saveAbsSrc = safeAbs(rp);
        if (saveAbsSrc !== saveAbsReq) {
          await ensureDir(saveAbsSrc);
          await fsp.writeFile(saveAbsSrc, remote.body);
        }
      } catch (_) {}

      res.statusCode = 200;
      res.setHeader("content-type", remoteCT || MIME[reqExt] || "application/octet-stream");
      res.setHeader("cache-control", "public, max-age=3600");
      res.end(remote.body);
      return true;
    } catch (_) {}
  }

  return false;
}

function proxyApi(req, res, urlObj) {
  return new Promise((resolve) => {
    const headers = { ...req.headers };
    headers.host = API_URL.host;
    delete headers["content-length"];

    const preq = API_CLIENT.request(
      {
        protocol: API_URL.protocol,
        hostname: API_URL.hostname,
        port: API_URL.port || (API_URL.protocol === "https:" ? 443 : 80),
        method: req.method,
        path: urlObj.pathname + urlObj.search,
        headers,
      },
      (pres) => {
        res.statusCode = pres.statusCode || 502;
        copyHeadersFromProxy(res, pres.headers);

        const setCookie = pres.headers["set-cookie"];
        if (Array.isArray(setCookie) && setCookie.length) {
          res.setHeader("set-cookie", setCookie.map(rewriteCookie));
        }

        pres.pipe(res);
        pres.on("end", () => resolve());
      }
    );

    preq.on("error", (e) => {
      res.statusCode = 502;
      res.setHeader("content-type", "text/plain; charset=utf-8");
      res.end("API proxy error: " + e.message);
      resolve();
    });

    req.pipe(preq);
  });
}

async function serveHtmlRoute(req, res, pathname, search) {
  const p = normalize(pathname);

  // try static html files first
  const htmlTry = [];
  htmlTry.push(p.endsWith("/") ? p + "index.html" : p + "/index.html");
  htmlTry.push(p);
  if (p.startsWith("/en")) {
    htmlTry.push("/en/index.html", "/ua/index.html", "/index.html");
  } else if (p.startsWith("/ua")) {
    htmlTry.push("/ua/index.html", "/index.html");
  } else {
    htmlTry.push("/ua/index.html", "/index.html");
  }

  for (const c of htmlTry) {
    const f = await findExistingFile(c);
    if (f) return sendFile(res, f);
  }

  // final fallback from remote html
  try {
    const remote = await fetchRemoteBinary(p + (search || ""), req.headers);
    if (remote.status === 200) {
      res.statusCode = 200;
      res.setHeader("content-type", "text/html; charset=utf-8");
      res.setHeader("cache-control", "no-store, no-cache, must-revalidate");
      return res.end(remote.body);
    }
  } catch (_) {}

  res.statusCode = 404;
  res.setHeader("content-type", "text/plain; charset=utf-8");
  res.end("Not Found");
}

const server = http.createServer(async (req, res) => {
  try {
    const urlObj = new URL(req.url || "/", `http://${req.headers.host || `localhost:${PORT}`}`);
    const pathname = decodeURIComponent(urlObj.pathname);

    if (pathname.startsWith("/api/")) {
      await proxyApi(req, res, urlObj);
      return;
    }

    const local = await findExistingFile(pathname);
    if (local) {
      await sendFile(res, local);
      return;
    }

    if (isAssetPath(pathname)) {
      const ok = await cacheAndSendAsset(req, res, pathname);
      if (ok) return;

      res.statusCode = 404;
      res.setHeader("content-type", "text/plain; charset=utf-8");
      res.end("Not Found");
      return;
    }

    await serveHtmlRoute(req, res, pathname, urlObj.search);
  } catch (e) {
    res.statusCode = 500;
    res.setHeader("content-type", "text/plain; charset=utf-8");
    res.end("Server error: " + (e?.message || String(e)));
  }
});

server.listen(PORT, () => {
  console.log(`Stage1 front server is ready on http://localhost:${PORT}`);
  console.log(`ROOT=${ROOT}`);
  console.log(`API_ORIGIN=${API_ORIGIN}`);
});
JS

echo "[3/7] ensure backend :9000 is running"
if ! curl -fsS "http://localhost:9000/app" >/dev/null 2>&1; then
  (cd "${HOME}/projects/namelaka-admin" && nohup npx medusa develop --port 9000 > "${BACK_LOG}" 2>&1 &)
  sleep 8
fi

echo "[4/7] start front :3000"
ROOT="${ROOT}" API_ORIGIN="${API_ORIGIN}" PORT=3000 nohup node "${FRONT_JS}" > "${FRONT_LOG}" 2>&1 &
sleep 2

echo "[5/7] warm pages and critical assets"
WARM=(
  "/ua/" "/en/"
  "/ua/catalog/" "/en/catalog/"
  "/ua/cart/" "/en/cart/"
  "/ua/assets/icons/search-primary.svg" "/en/assets/icons/search-primary.svg"
  "/ua/assets/icons/logo-header-primary.svg" "/en/assets/icons/logo-header-primary.svg"
  "/ua/assets/icons/cart-secondary.svg" "/en/assets/icons/cart-secondary.svg"
  "/ua/assets/icons/user-icon-disabled.svg" "/en/assets/icons/user-icon-disabled.svg"
  "/ua/assets/icons/double-tick-primary.svg" "/en/assets/icons/double-tick-primary.svg"
  "/ua/assets/icons/person-disabled.svg" "/en/assets/icons/person-disabled.svg"
  "/ua/assets/icons/patterns/pattern.svg" "/en/assets/icons/patterns/pattern.svg"
  "/ua/assets/lottie/fast-loader.json" "/en/assets/lottie/fast-loader.json"
  "/ua/media/pattern-4VTAGWQZ.svg" "/en/media/pattern-4VTAGWQZ.svg"
)
for p in "${WARM[@]}"; do
  curl -L -s "http://localhost:3000${p}" >/dev/null || true
done

echo "[6/7] checks"
CHECK=(
  "/ua/" "/en/" "/ua/catalog/" "/en/catalog/" "/ua/cart/" "/en/cart/"
  "/ua/assets/icons/search-primary.svg" "/en/assets/icons/search-primary.svg"
  "/ua/assets/icons/logo-header-primary.svg" "/en/assets/icons/logo-header-primary.svg"
  "/ua/assets/icons/cart-secondary.svg" "/en/assets/icons/cart-secondary.svg"
  "/ua/assets/icons/user-icon-disabled.svg" "/en/assets/icons/user-icon-disabled.svg"
  "/ua/assets/icons/double-tick-primary.svg" "/en/assets/icons/double-tick-primary.svg"
  "/ua/assets/icons/person-disabled.svg" "/en/assets/icons/person-disabled.svg"
  "/ua/assets/icons/patterns/pattern.svg" "/en/assets/icons/patterns/pattern.svg"
  "/ua/assets/lottie/fast-loader.json" "/en/assets/lottie/fast-loader.json"
  "/api/categories?lang=ua" "/api/categories?lang=en"
)
for p in "${CHECK[@]}"; do
  code="$(curl -L -s -o /dev/null -w '%{http_code}' "http://localhost:3000${p}" || true)"
  printf "%-55s -> %s\n" "${p}" "${code}"
done

echo "[7/7] done"
echo "Front UA: http://localhost:3000/ua/"
echo "Front EN: http://localhost:3000/en/"
echo "Admin:    http://localhost:9000/app"
echo "Login:    admin@namelaka.local"
echo "Pass:     StrongPass123!"
echo
echo "Logs:"
echo "tail -f ${FRONT_LOG}"
echo "tail -f ${BACK_LOG}"
